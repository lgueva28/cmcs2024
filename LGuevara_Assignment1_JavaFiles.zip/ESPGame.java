/*
 * Class: CMSC203 
 * Instructor:Prof. Aygun
 * Description: The program should randomly select the name of a color from list of words in a file colors.txt 
 * Due: September 16th, 2024
 * Platform/compiler: Eclipse 
 * I pledge that I have completed the programming assignment 
* independently. I have not copied the code from a student or   * any source. I have not given my code to any student.
 * Print your Name here: Leslie N Guevara Amaya
*/
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class ESPGame {
    // Constants for the number of colors
    private static final int NUM_COLORS = 16;

    public static void main(String[] args) {
        final String FILENAME = "colors.txt"; // Path to the file used
        final String[] COLORS = new String[NUM_COLORS]; // Array to store color names

        // Print the current working directory
        // REMOVE
        System.out.println("Current working directory: " + System.getProperty("user.dir"));

        // Read colors from the file
        try (BufferedReader reader = new BufferedReader(new FileReader(FILENAME))) {
            System.out.println("There are sixteen colors from the file:");
            for (int i = 0; i < NUM_COLORS; i++) {
                String color = reader.readLine().trim();
                if (color == null) {
                    throw new IOException("File does not contain enough colors.");
                }
                COLORS[i] = color;
                System.out.println((i + 1) + " " + COLORS[i]);
            }
        } catch (IOException e) {
            System.err.println("Error reading the colors file: " + e.getMessage());
            return;
        }

        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        int correctGuesses = 0;
        int numTrials = 3;

        // Game loop
        for (int round = 1; round <= numTrials; round++) {
            System.out.println("\nRound " + round);
            System.out.println("I am thinking of a color.");
            System.out.println("Is it one of the list of colors above?");
            System.out.print("Enter your guess: ");
            
            String guess = scanner.nextLine().trim();
            String selectedColor = COLORS[random.nextInt(NUM_COLORS)];
            
            // Normalize guess for comparison
            String normalizedGuess = guess.toLowerCase();
            String normalizedSelectedColor = selectedColor.toLowerCase();
            
            if (normalizedGuess.equals(normalizedSelectedColor)) {
                System.out.println("I was thinking of " + selectedColor + ".");
                correctGuesses++;
            } else {
                System.out.println("I was thinking of " + selectedColor + ".");
            }
        }

        // End of game
        System.out.println("\nGame Over");
        System.out.println("You guessed " + correctGuesses + " out of " + numTrials + " colors correctly.");

        // Get additional user information
        System.out.print("Enter your name: ");
        String name = scanner.nextLine().trim();

        System.out.print("Describe yourself: ");
        String description = scanner.nextLine().trim();

        System.out.print("Due Date (MM/DD): ");
        String dueDate = scanner.nextLine().trim();

        // Display user information
        System.out.println("User Name: " + name);
        System.out.println("User Description: " + description);
        System.out.println("Date: " + dueDate);

        scanner.close();
    }
}
